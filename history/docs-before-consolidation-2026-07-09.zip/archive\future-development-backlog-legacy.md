# AIoT 智能设备运行日志管理系统 - 后续开发归档

## Docker 正式发布计划

当前 `docker-compose.yml` 属于源码构建版，适合开发验证。正式提供给其他用户时按以下步骤完善：

1. 完成本机四容器联调，验证前端、后端、MySQL 和 Mosquitto。
2. 分离日常启动与更新构建脚本：
   - `docker-start.cmd` 只启动已有镜像和容器。
   - `docker-update.cmd` 负责拉取或重新构建新版本。
3. 提前构建前端和后端成品镜像，Compose 正式版使用 `image:`，不要求用户现场安装 Node、Maven 或 JDK。
4. 将前端、后端、MySQL 和 Mosquitto 所需镜像发布或同步到国内容器镜像仓库。
5. GitHub 保留源码、开发构建文件和部署说明；README 同时提供国内镜像部署方式。
6. 后续代码更新通过版本标签发布，例如 `1.0.0`、`1.1.0`，用户只需拉取发生变化的镜像层。
7. 项目具备服务器条件后增加在线演示地址，普通用户无需安装 Docker。

国内镜像仓库账号、命名空间和镜像地址将在正式发布前确定，当前不写死具体厂商。

> 2026-07-09 更新：Docker Compose 一键部署首版及根目录 README 已完成。P0 后续主要工作为实际 Docker 环境验收、补充项目截图和完善 GitHub 展示。

本文档用于归档暂停期间暂不开发、但后续值得补强的功能。当前项目先暂停业务开发，等待真实设备项目完成后再继续接入和完善。

## 1. 当前技术栈说明

当前技术栈不落后，属于 Java 后端、Vue 管理系统和 IoT 场景里常见的组合。

| 层级 | 当前技术 | 说明 |
| --- | --- | --- |
| 前端 | Vue 3 + TypeScript + Vite | 当前主流前端管理系统组合 |
| UI 组件 | Element Plus | Vue 3 后台管理系统常用组件库 |
| 状态/路由 | Pinia + Vue Router | Vue 3 标准生态 |
| HTTP 请求 | Axios | 前端调用后端接口 |
| 后端 | Spring Boot 3.3.5 | Java 后端主流框架 |
| Java | JDK 17 | Spring Boot 3 要求 Java 17 起步 |
| ORM | MyBatis Plus | 国内 Java 项目常见，适合 CRUD 管理系统 |
| 数据库 | MySQL 8.4 | 结构化业务数据存储 |
| 设备上报 | HTTP + MQTT | HTTP 简单直连，MQTT 适合 IoT 发布订阅 |
| MQTT Broker | Mosquitto | 轻量 MQTT 服务端 |
| 本地启动 | PowerShell + CMD 脚本 | 当前开发环境一键启动 |

## 2. 当前项目适合展示的能力

- 设备管理、日志管理、标签管理、首页统计。
- HTTP 设备自动上报。
- MQTT 设备自动上报。
- 异常上报自动生成日志。
- 告警规则配置。
- 设备详情上报数据和趋势图展示。
- MQTT 状态页。
- 一键启动和一键停止脚本。
- 项目文档按需求、数据库、接口、前端、状态、开发日志拆分维护。

## 3. 后续优先级

### P0：GitHub 展示和一键部署

这些内容优先级最高，适合项目作为作品展示。

- 整理根目录 `README.md`，包含项目介绍、功能截图、技术栈、启动方式、架构图。
- 补充项目截图：首页、设备管理、设备详情、日志管理、告警规则、MQTT 状态。
- 增加 Docker Compose 一键部署：
  - MySQL 容器
  - Mosquitto 容器
  - Spring Boot 后端容器
  - Vue/Nginx 前端容器
- 增加 Docker 环境配置：
  - `backend/Dockerfile`
  - `frontend/Dockerfile`
  - `docker-compose.yml`
  - `docker/mosquitto/mosquitto.conf`
  - 数据库初始化脚本挂载
- README 中提供一键启动命令：

```bash
docker compose up -d
```

### P1：真实设备接入

等待设备项目完成后继续。

- 确认真实设备通信方式：WiFi、网线、4G、串口网关或其他。
- 确认真实设备选择 HTTP 还是 MQTT 上报。
- 如果走 MQTT：
  - 配置 Mosquitto 局域网访问。
  - 配置 Windows 防火墙或服务器安全组放行 `1883`。
  - 真实设备发布到 `aiot/device/{deviceCode}/report`。
- 如果走 HTTP：
  - 后端开放 `8080` 或通过 Nginx 反向代理。
  - 真实设备 POST 到 `/api/device-reports`。
- 增加真实设备接入记录文档。

### P2：安全和权限

这些内容能明显提升项目完整度。

- 登录认证：Spring Security + JWT。
- 密码加密：BCrypt。
- 用户角色：
  - 管理员
  - 运维人员
  - 普通查看用户
- 前端路由权限控制。
- 接口鉴权。
- MQTT 用户名和密码。
- 生产环境禁用匿名 MQTT 访问。

### P3：工程化增强

这些内容更贴近真实岗位项目。

- Redis：
  - 登录 token 缓存
  - 验证码缓存
  - 热点统计缓存
- Swagger / OpenAPI 接口文档。
- Nginx 前端部署和后端反向代理。
- 后端统一日志格式。
- 后端 Actuator 健康检查。
- 参数错误提示继续细化。
- Maven package 在 Windows 下 jar 重命名占用问题处理。

### P4：AI 功能第三阶段

第三阶段可以作为项目亮点，但不建议在基础部署和权限之前优先做。

- 日志智能总结。
- 异常原因分析。
- 维护建议生成。
- 设备异常历史关联分析。
- AI 分析结果表设计和页面展示。

## 4. 暂停期间保持的状态

当前暂停时，项目应保持：

- 本地一键启动可用。
- 后端编译通过。
- 前端构建通过。
- 文档已同步到第二阶段 MQTT 首版完成状态。
- 真实设备接入前，不继续扩大业务功能。

## 5. 恢复开发建议顺序

恢复开发时建议按这个顺序：

1. 先整理 GitHub README 和截图。
2. 做 Docker Compose 一键部署。
3. 等真实设备完成后做真实设备联调。
4. 补登录权限和 MQTT 安全配置。
5. 再进入第三阶段 AI 功能。
