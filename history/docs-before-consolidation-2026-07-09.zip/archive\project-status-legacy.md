# AIoT 智能设备运行日志管理系统 - 当前项目进度

## 2026-07-09 Docker 中文数据修复完成

Docker 初始演示数据的中文乱码已原地修复，数据库查询与 HTTP 原始 UTF-8 响应验证通过。初始化 SQL、JDBC 连接和后端响应编码均已补充 UTF-8 配置。浏览器刷新后可查看正确中文；后端编码配置将在下一次执行 `docker-update.cmd` 后进入容器镜像。

## 2026-07-09 Docker 一键部署验收完成

Docker Compose 首次完整联调已经通过：

- MySQL、Mosquitto、Spring Boot 后端、Vue/Nginx 前端四个容器全部运行。
- MySQL 容器健康检查通过。
- 管理网页返回 HTTP `200`。
- 后端首页统计接口返回业务码 `200`。
- MQTT 状态接口返回业务码 `200`，连接状态为 `connected=true`。
- `docker-start.cmd` 已改为日常快速启动，不再每次重新构建。
- 新增 `docker-update.cmd`，只在首次部署或代码更新后执行构建。
- `docker-stop.cmd` 继续用于停止服务并保留数据库数据。

## 2026-07-09 Docker 构建继续推进

基础镜像拉取问题已基本解决，首次 Compose 构建已进入后端 Maven 依赖下载阶段。针对 Maven Central 下载中断，已切换 Docker 构建专用国内 Maven 镜像，并增加依赖缓存与自动重试。下一步重新执行 `docker-start.cmd`，继续完成前后端镜像构建和四服务联调。

## 2026-07-09 Docker 首次联调暂停点

当前 Docker Desktop、WSL 2 和 Docker Compose 已可用，MySQL 与 Mosquitto 基础镜像已经成功拉取。前后端镜像构建尚未完成，当前阻塞原因是国内网络访问 Docker Hub 的 `auth.docker.io` 不稳定，并非项目代码或 Dockerfile 错误。

当前进度：

- `mysql:8.4`：已拉取
- `eclipse-mosquitto:2`：已拉取
- `node:22-alpine`：已就绪
- `maven:3.9.9-eclipse-temurin-17`：已就绪
- `nginx:1.27-alpine`：已拉取
- `eclipse-temurin:17-jre`：待确认拉取完成
- 前端和后端项目镜像：待基础镜像齐全后构建
- 四个服务的完整启动与页面验收：待完成

恢复联调时只需先拉取剩余的 `eclipse-temurin:17-jre` 基础镜像，再运行 `docker-start.cmd`。首次本机验证完成后，应制作并发布前后端成品镜像，减少其他用户现场构建和访问国外 Docker Hub 的依赖。

## 2026-07-09 Docker 部署进度

Docker Compose 一键部署首版已完成：

- MySQL 8.4 容器与首次启动 SQL 初始化
- Mosquitto 2 容器与局域网 MQTT 监听
- Spring Boot 多阶段构建与容器运行
- Vue 多阶段构建、Nginx 静态部署和 `/api` 反向代理
- `docker-start.cmd` 一键构建、启动并打开网页
- `docker-stop.cmd` 一键停止且保留数据库数据
- 后端 MySQL、MQTT 参数支持环境变量覆盖，同时兼容原本地启动

当前仍需在实际 Docker Desktop 环境完成首次镜像构建和页面联调。真实设备接入仍需设备配置部署电脑的局域网 IP，Docker 不负责连接 WiFi。

更新时间：2026-07-08

## 1. 当前阶段

当前处于第二阶段初期：

```text
第二阶段：设备自动上报能力
状态：HTTP 上报、MQTT 上报、异常日志自动生成、上报趋势图和告警规则配置已完成首版
```

第一阶段目标：

- 设备管理
- 日志管理
- 标签管理
- 日志筛选
- 首页统计
- 基础可视化页面

第一阶段已完成并通过第一轮功能验收；第二阶段设备自动上报能力已完成首版联调。

## 2. 已完成内容

### 2.1 文档设计

已完成：

- 第一阶段需求文档
- 数据库设计
- 后端 API 设计
- 前端页面设计
- 后端实现路线
- 后端模块文件地图
- 技术决策记录
- 开发日志

### 2.2 数据库

已完成：

- MySQL 8.4.9 本地运行
- 项目本地数据目录 `D:\AI\IOT\mysql-data`
- 数据库 `aiot_log_system`
- 设备、日志、标签、日志标签关联表
- 初始化演示数据

当前数据来源：

```text
sql/schema.sql
sql/init-data.sql
```

### 2.3 后端

技术栈：

```text
Java 17
Spring Boot 3.3.5
MyBatis Plus 3.5.5
MySQL Connector/J
Maven 3.9.16
```

已完成模块：

- 统一 API 响应
- 全局异常处理
- 跨域配置
- MyBatis Plus 配置
- 设备管理接口
- 日志管理接口
- 标签管理接口
- 日志标签关联
- 首页统计接口
- 枚举接口
- 根路径服务说明接口

已验证接口：

```text
GET  /
GET  /api/enums
GET  /api/dashboard/summary
GET  /api/devices
GET  /api/devices/{id}
GET  /api/logs
GET  /api/logs?tagId=1
GET  /api/tags
POST /api/tags
```

### 2.4 前端

技术栈：

```text
Vue 3
TypeScript
Vite
Vue Router
Pinia
Element Plus
Axios
```

已完成页面：

```text
/dashboard   首页统计
/devices     设备管理
/devices/:id 设备详情
/logs        日志管理
/tags        标签管理
```

已完成能力：

- 左侧导航
- 顶部标题栏
- 首页统计卡片
- 设备表格
- 设备新增、编辑、删除
- 设备详情
- 日志表格
- 日志新增、编辑、删除
- 日志状态修改
- 日志筛选
- 标签新增、删除
- 状态标签展示
- 前端 `/api` 代理到后端 `8080`

### 2.5 一键启动

已完成：

```text
start-all.ps1
start-all.cmd
```

双击或执行：

```text
D:\AI\IOT\start-all.cmd
```

脚本会自动：

1. 检查并启动 MySQL。
2. 检查并启动本地 MQTT Broker（已安装 Mosquitto 时）。
3. 检查并启动 Spring Boot 后端。
4. 检查并启动 Vite 前端。
5. 打开浏览器访问前端页面。

浏览器打开方式：

```text
cmd /c start "" "http://127.0.0.1:5173/"
```

访问地址：

```text
前端页面：http://127.0.0.1:5173/
后端接口：http://127.0.0.1:8080/
MySQL：127.0.0.1:3306
MQTT：127.0.0.1:1883
```

## 3. 当前验证结果

后端编译：

```text
mvn compile
BUILD SUCCESS
```

前端构建：

```text
npm run build
BUILD SUCCESS
```

一键启动脚本：

```text
MySQL already running on 127.0.0.1:3306
Backend already running on 127.0.0.1:8080
Frontend already running on 127.0.0.1:5173
Opening http://127.0.0.1:5173/
All services are ready.
```

完整演示流程测试：

```text
新增设备      通过
新增日志      通过
日志筛选      通过
修改日志状态  通过
新增标签      通过
删除标签      通过
```

## 4. 当前未完成或待优化

第一阶段待完善：

- 前端交互细节优化。
- 前端表单校验和错误提示继续完善。
- 页面视觉细节继续调整。

技术待处理：

- 后端 `mvn package` 在 Windows 上存在 jar 重命名占用问题，当前开发阶段使用 `spring-boot:run`。
- 生产部署方式尚未整理。
- GitHub 展示、Docker Compose 一键部署、登录权限、Redis、Nginx、OpenAPI 等增强项已归档到 `docs/future-development-backlog.md`。

第二阶段已完成首版：

- HTTP 设备上报接口：`POST /api/device-reports`。
- 设备上报数据查询接口：`GET /api/device-reports`。
- 新增设备上报数据表：`device_reports`。
- 模拟设备数据上报脚本：`tools/simulate-device-report.ps1`。
- 自动生成异常日志：状态异常、温度过高、电压过低、信号过弱会写入 `logs`。
- 前端设备详情页展示最近上报数据。
- 日志列表支持来源筛选：人工录入、设备上报、系统生成。
- 日志列表和设备详情最近日志支持来源中文展示。
- 设备详情页展示上报趋势图：温度、湿度、电压、信号强度。
- 告警规则配置：支持新增、编辑、删除、启用/停用规则。
- 设备上报异常判断优先使用告警规则；没有规则时保留默认阈值。
- MQTT 可选接入：后端支持订阅 `aiot/device/+/report`，收到消息后复用设备上报逻辑。
- MQTT 模拟发布脚本：`tools/simulate-mqtt-report.ps1`。
- 本机 Mosquitto MQTT Broker 已安装并完成真实发布订阅联调。
- MQTT 正常上报和异常上报均已验证入库，异常上报已验证自动生成来源为 `DEVICE` 的日志。
- MQTT 状态接口：`GET /api/mqtt/status`。
- MQTT 状态页面：`/mqtt`。
- MQTT 正式上报说明：`docs/mqtt-reporting-guide.md`。

第二阶段待继续：

- MQTT 参数校验和错误提示继续增强。
- 局域网真实设备接入时，按需整理 Mosquitto 远程访问配置和安全策略。

第三阶段待开始：

- 日志智能总结。
- 异常分析。
- 维护建议。

## 5. 下一步建议

建议下一步：

```text
暂停业务开发，等待真实设备项目完成；恢复开发时优先整理 GitHub README、截图和 Docker Compose 一键部署。
```

第二阶段建议顺序：

1. 启动后端并执行 `sql/schema.sql` 确保本地库包含 `device_reports`。
2. 运行 `tools/simulate-device-report.ps1 -IncludeAbnormal`。
3. 在设备详情页查看最近上报数据。
4. 在设备详情页查看上报趋势图。
5. 在日志列表查看自动生成的设备异常日志，并按来源筛选 `DEVICE`。
6. 在告警规则页配置阈值后，再运行模拟上报验证自动告警。
7. Mosquitto、MQTT 状态展示和上报协议说明已完成；后续按真实设备接入场景补充局域网访问和安全配置。
