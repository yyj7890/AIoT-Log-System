# 历史文档说明

本目录保存已经完成、容易过期或重写前的文档，内容未删除。

- `backend-implementation-plan.md`：第一阶段后端实现步骤，当前已完成。
- `backend-module-map.md`：早期后端文件地图，实际目录结构以代码为准。
- `project-status-legacy.md`：精简前的完整项目状态。
- `future-development-backlog-legacy.md`：精简前的完整后续计划。
- `README-legacy.md`：整理前的文档索引。
- `development-log-legacy.md`：整理前的完整开发记录，保留原始编号、命令和故障过程。

追溯历史时可以阅读，但继续开发时优先使用上级目录中的当前文档。
