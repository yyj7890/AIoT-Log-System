# AIoT 智能设备运行日志管理系统 - 后端实现路线

本文档说明后端代码按什么顺序实现、为什么这样安排、每一步要写哪些类、完成后如何验收。

## 1. 实现原则

后端实现遵循以下原则：

- 先实现核心业务闭环，再扩展辅助功能。
- 每完成一个模块，都要能编译通过。
- 每个模块完成后同步更新开发记录。
- 接口实现以 `backend-api-design.md` 为准。
- 数据库字段以 `database-design.md` 和 `sql/schema.sql` 为准。

## 2. 当前后端技术栈

详细技术决策见 `technical-decisions.md`。

当前后端采用：

- JDK 17
- Spring Boot 3.3.5
- MyBatis Plus
- MySQL 8.x
- Maven 3.9.16

## 3. 后端模块实现顺序

### 3.1 第一步：后端基础工程

状态：已完成。

目标：

- 搭建 Spring Boot 3 项目。
- 配置 MySQL。
- 配置 MyBatis Plus。
- 建立基础包结构。
- 建立统一响应和异常处理。

已完成文件类型：

- 启动类
- `common`
- `config`
- `exception`
- `entity`
- `mapper`

验收方式：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

当前结果：

```text
BUILD SUCCESS
```

### 3.2 第二步：设备管理接口

状态：已完成。

为什么先做：

- 设备是日志的归属对象。
- 不先完成设备接口，日志新增时无法选择所属设备。
- 首页统计和设备详情都依赖设备数据。

对应需求：

- `phase-1-requirements.md` 的设备管理部分。

对应 API：

- `backend-api-design.md` 的设备 API 部分。

已实现接口：

```text
GET    /api/devices
GET    /api/devices/{id}
POST   /api/devices
PUT    /api/devices/{id}
DELETE /api/devices/{id}
```

已实现规则：

- 设备编号唯一。
- 设备状态合法校验。
- 设备不存在时返回业务错误。
- 设备下存在日志时不允许删除。

验收方式：

- 编译通过。
- 后续连接数据库后使用接口工具验证 CRUD。

### 3.3 第三步：日志管理接口

状态：已完成第一版。

为什么第二个做日志：

- 本项目核心是“设备运行日志管理系统”，日志是核心业务对象。
- 设备接口完成后，日志就可以关联设备。
- 设备详情中的最近日志、异常日志数、待处理日志数依赖日志数据。
- 首页统计中的待处理日志、最近异常日志、最近维护记录依赖日志数据。
- 标签筛选也以日志为主体。

对应需求：

- `phase-1-requirements.md` 的日志管理部分。

对应 API：

- `backend-api-design.md` 的日志 API 部分。

需要实现的接口：

```text
GET    /api/logs
GET    /api/logs/{id}
POST   /api/logs
PUT    /api/logs/{id}
PATCH  /api/logs/{id}/status
DELETE /api/logs/{id}
```

已新增或完善的代码：

```text
entity/LogRecord.java            已存在
mapper/LogRecordMapper.java      已存在
dto/LogCreateRequest.java        已新增
dto/LogUpdateRequest.java        已新增
dto/LogStatusUpdateRequest.java  已新增
vo/LogVO.java                    已新增
vo/TagVO.java                    已新增
enums/LogType.java               已新增
enums/LogLevel.java              已新增
enums/LogStatus.java             已新增
service/LogService.java          已新增
service/impl/LogServiceImpl.java 已新增
controller/LogController.java    已新增
```

核心业务规则：

- 新增日志时，设备必须存在。
- 日志类型必须合法。
- 日志等级必须合法。
- 日志状态必须合法。
- 日志来源第一阶段默认 `MANUAL`。
- 删除日志时同步删除 `log_tags` 关联关系。
- 查询日志列表支持设备、类型、等级、状态、关键词、时间范围筛选。

第一版已实现范围：

- 先实现不带标签的日志 CRUD 和筛选。
- 标签关联可以在标签模块完成后补充。
- 请求 DTO 保留 `tagIds` 字段，当前暂不处理。
- `tagId` 筛选当前返回业务错误，等标签模块完成后支持。

验收结果：

- 后端 `mvn compile` 编译通过。
- 接口代码已完成，待连接数据库后使用接口工具验证。

### 3.4 第四步：标签管理接口

状态：已完成。

为什么在日志之后做：

- 标签服务于日志筛选和分类。
- 先有日志 CRUD，再接标签关联更清晰。

对应需求：

- `phase-1-requirements.md` 的标签和筛选部分。

对应 API：

- `backend-api-design.md` 的标签 API 部分。

需要实现的接口：

```text
GET    /api/tags
POST   /api/tags
DELETE /api/tags/{id}
```

需要新增代码：

```text
entity/Tag.java
entity/LogTag.java
mapper/TagMapper.java
mapper/LogTagMapper.java
dto/TagCreateRequest.java
vo/TagVO.java
service/TagService.java
service/impl/TagServiceImpl.java
controller/TagController.java
```

核心业务规则：

- 标签名称不能为空。
- 标签名称不能重复。
- 删除标签时同步删除日志标签关联。

验收方式：

- 后端 `mvn compile` 编译通过。
- 标签接口代码已完成，待连接数据库后使用接口工具验证。

### 3.5 第五步：日志标签关联

状态：已完成。

为什么单独列出：

- 日志和标签是多对多关系。
- 直接混在日志 CRUD 中容易一次改动过大。
- 先完成日志和标签各自基础接口，再处理关联更稳。

需要补充：

- 新增日志时支持 `tagIds`。
- 编辑日志时更新 `tagIds`。
- 查询日志详情时返回标签列表。
- 日志列表支持 `tagId` 筛选。

验收结果：

- 后端 `mvn compile` 编译通过。
- 接口代码已完成，待连接数据库后使用接口工具验证。

### 3.6 第六步：首页统计接口

状态：已完成。

为什么放在日志和标签之后：

- 首页统计依赖设备、日志数据。
- 最近异常日志和最近维护记录需要日志接口相关查询能力。

对应 API：

```text
GET /api/dashboard/summary
```

需要新增代码：

```text
vo/DashboardSummaryVO.java
service/DashboardService.java
service/impl/DashboardServiceImpl.java
controller/DashboardController.java
```

统计内容：

- 设备总数
- 正常设备数
- 异常设备数
- 离线设备数
- 维护中设备数
- 待处理日志数
- 最近异常日志
- 最近维护记录

验收结果：

- 后端 `mvn compile` 编译通过。
- 接口代码已完成，待连接数据库后使用接口工具验证。

### 3.7 第七步：枚举接口

状态：已完成。

为什么最后做：

- 枚举接口主要服务前端下拉框。
- 等设备、日志状态和类型都稳定后再输出更合适。

对应 API：

```text
GET /api/enums
```

返回内容：

- 设备状态
- 日志类型
- 日志等级
- 日志处理状态

验收结果：

- 后端 `mvn compile` 编译通过。
- 接口代码已完成，前端可使用返回值渲染下拉框。

## 4. 当前下一步

当前明确下一步：

```text
继续完善前端页面交互细节，并进行完整演示流程测试。
```

后端运行测试重点：

1. 创建并初始化 MySQL 数据库。
2. 检查 `application.yml` 数据库账号密码。
3. 启动 Spring Boot 后端。
4. 测试设备、日志、标签、首页统计、枚举接口。

后端运行测试结果：

```text
2026-07-07 已完成 MySQL 连接、后端启动和核心接口验证。
GET  /api/enums                  200
GET  /api/dashboard/summary      200
GET  /api/logs?page=1&pageSize=3 200
GET  /api/tags                   200
POST /api/tags                   200
```

暂缓：

- jar 打包发布流程。

原因：

- 当前开发阶段可通过 `spring-boot:run` 稳定启动；jar 打包在 Windows 上遇到文件重命名占用问题，后续发布前再处理。

## 5. 每步完成后的固定流程

每完成一个模块，都执行：

1. 编译后端。
2. 修复编译错误。
3. 更新 `development-log.md`。
4. 如果有技术版本或架构变化，更新 `technical-decisions.md`。
5. 如果接口变化，更新 `backend-api-design.md`。
6. 如果数据库变化，更新 `database-design.md` 和 SQL 脚本。

编译命令：

```powershell
cd D:\AI\IOT\backend
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;D:\AI\IOT\tools\apache-maven-3.9.16\bin;$env:Path"
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```
