# AIoT 智能设备运行日志管理系统 - 后端模块文件地图

本文档用于说明后端每个模块对应哪些文件、文件位于哪个目录、每个文件负责什么。

后端代码根目录：

```text
backend/src/main/java/com/aiot/log
```

## 1. 后端总目录结构

```text
backend/src/main/java/com/aiot/log
├── AiotLogBackendApplication.java
├── common
│   ├── ApiResponse.java
│   └── PageResult.java
├── config
│   ├── MybatisPlusConfig.java
│   └── WebConfig.java
├── controller
│   ├── DeviceController.java
│   ├── DashboardController.java
│   ├── EnumController.java
│   ├── LogController.java
│   └── TagController.java
├── dto
│   ├── DeviceCreateRequest.java
│   ├── DeviceUpdateRequest.java
│   ├── LogCreateRequest.java
│   ├── LogStatusUpdateRequest.java
│   ├── LogUpdateRequest.java
│   └── TagCreateRequest.java
├── entity
│   ├── Device.java
│   ├── LogRecord.java
│   ├── LogTag.java
│   └── Tag.java
├── enums
│   ├── DeviceStatus.java
│   ├── LogLevel.java
│   ├── LogStatus.java
│   └── LogType.java
├── exception
│   ├── BusinessException.java
│   └── GlobalExceptionHandler.java
├── mapper
│   ├── DeviceMapper.java
│   ├── LogRecordMapper.java
│   ├── LogTagMapper.java
│   └── TagMapper.java
├── service
│   ├── DeviceService.java
│   ├── DashboardService.java
│   ├── LogService.java
│   ├── TagService.java
│   └── impl
│       ├── DashboardServiceImpl.java
│       ├── DeviceServiceImpl.java
│       ├── LogServiceImpl.java
│       └── TagServiceImpl.java
└── vo
    ├── DeviceVO.java
    ├── DashboardSummaryVO.java
    ├── EnumOptionVO.java
    ├── LogBriefVO.java
    ├── LogVO.java
    └── TagVO.java
```

## 2. 公共基础模块

公共基础模块不是某个业务独有，而是设备、日志、标签、首页统计都会用到。

```text
backend/src/main/java/com/aiot/log
├── AiotLogBackendApplication.java
├── common
│   ├── ApiResponse.java
│   └── PageResult.java
├── config
│   ├── MybatisPlusConfig.java
│   └── WebConfig.java
└── exception
    ├── BusinessException.java
    └── GlobalExceptionHandler.java
```

文件说明：

| 文件 | 作用 |
| --- | --- |
| `AiotLogBackendApplication.java` | Spring Boot 启动类 |
| `common/ApiResponse.java` | 统一接口响应结构 |
| `common/PageResult.java` | 分页响应结构 |
| `config/MybatisPlusConfig.java` | MyBatis Plus 分页插件配置 |
| `config/WebConfig.java` | 跨域配置，方便前端访问后端 |
| `exception/BusinessException.java` | 自定义业务异常 |
| `exception/GlobalExceptionHandler.java` | 全局异常处理 |

## 3. 设备管理模块

设备管理模块负责设备列表、详情、新增、编辑、删除。

目录树：

```text
backend/src/main/java/com/aiot/log
├── controller
│   └── DeviceController.java
├── dto
│   ├── DeviceCreateRequest.java
│   └── DeviceUpdateRequest.java
├── entity
│   └── Device.java
├── enums
│   └── DeviceStatus.java
├── mapper
│   └── DeviceMapper.java
├── service
│   ├── DeviceService.java
│   └── impl
│       └── DeviceServiceImpl.java
└── vo
    └── DeviceVO.java
```

文件说明：

| 文件 | 作用 |
| --- | --- |
| `controller/DeviceController.java` | 设备 REST API 入口 |
| `service/DeviceService.java` | 设备业务接口 |
| `service/impl/DeviceServiceImpl.java` | 设备业务实现 |
| `mapper/DeviceMapper.java` | 设备表数据库访问 |
| `entity/Device.java` | 对应数据库 `devices` 表 |
| `dto/DeviceCreateRequest.java` | 新增设备请求参数 |
| `dto/DeviceUpdateRequest.java` | 编辑设备请求参数 |
| `vo/DeviceVO.java` | 设备接口返回对象 |
| `enums/DeviceStatus.java` | 设备状态合法值 |

已实现接口：

```text
GET    /api/devices
GET    /api/devices/{id}
POST   /api/devices
PUT    /api/devices/{id}
DELETE /api/devices/{id}
```

## 4. 日志管理模块

日志管理模块负责日志列表、详情、新增、编辑、删除、状态修改和筛选。

目录树：

```text
backend/src/main/java/com/aiot/log
├── controller
│   └── LogController.java
├── dto
│   ├── LogCreateRequest.java
│   ├── LogStatusUpdateRequest.java
│   └── LogUpdateRequest.java
├── entity
│   └── LogRecord.java
├── enums
│   ├── LogLevel.java
│   ├── LogStatus.java
│   └── LogType.java
├── mapper
│   └── LogRecordMapper.java
├── service
│   ├── LogService.java
│   └── impl
│       └── LogServiceImpl.java
└── vo
    ├── LogBriefVO.java
    ├── LogVO.java
    └── TagVO.java
```

文件说明：

| 文件 | 作用 |
| --- | --- |
| `controller/LogController.java` | 日志 REST API 入口 |
| `service/LogService.java` | 日志业务接口 |
| `service/impl/LogServiceImpl.java` | 日志业务实现 |
| `mapper/LogRecordMapper.java` | 日志表数据库访问 |
| `entity/LogRecord.java` | 对应数据库 `logs` 表 |
| `dto/LogCreateRequest.java` | 新增日志请求参数 |
| `dto/LogUpdateRequest.java` | 编辑日志请求参数 |
| `dto/LogStatusUpdateRequest.java` | 修改日志状态请求参数 |
| `vo/LogVO.java` | 日志列表和详情返回对象 |
| `vo/LogBriefVO.java` | 设备详情、首页等场景使用的简略日志对象 |
| `vo/TagVO.java` | 日志返回中的标签对象，当前预留，后续标签模块使用 |
| `enums/LogType.java` | 日志类型合法值 |
| `enums/LogLevel.java` | 日志等级合法值 |
| `enums/LogStatus.java` | 日志处理状态合法值 |

已实现接口：

```text
GET    /api/logs
GET    /api/logs/{id}
POST   /api/logs
PUT    /api/logs/{id}
PATCH  /api/logs/{id}/status
DELETE /api/logs/{id}
```

当前说明：

- 日志接口第一版已完成。
- `LogCreateRequest` 和 `LogUpdateRequest` 中已预留 `tagIds`。
- `TagVO` 已预留。
- 日志标签关联尚未实现。
- 按标签筛选尚未实现。

## 5. 标签管理模块

标签管理模块负责标签列表、新增、删除，并为日志标签关联提供基础数据。

目录树：

```text
backend/src/main/java/com/aiot/log
├── controller
│   └── TagController.java
├── dto
│   └── TagCreateRequest.java
├── entity
│   ├── Tag.java
│   └── LogTag.java
├── mapper
│   ├── TagMapper.java
│   └── LogTagMapper.java
├── service
│   ├── TagService.java
│   └── impl
│       └── TagServiceImpl.java
└── vo
    └── TagVO.java
```

已实现接口：

```text
GET    /api/tags
POST   /api/tags
DELETE /api/tags/{id}
```

标签模块完成后，还需要回到日志模块补充：

```text
LogServiceImpl.java
```

已补充内容：

- 新增日志时保存 `tagIds`。
- 编辑日志时更新 `tagIds`。
- 查询日志时返回标签列表。
- 日志列表支持 `tagId` 筛选。

## 6. 首页统计模块

首页统计模块负责首页设备和日志概览。

目录树：

```text
backend/src/main/java/com/aiot/log
├── controller
│   └── DashboardController.java
├── service
│   ├── DashboardService.java
│   └── impl
│       └── DashboardServiceImpl.java
└── vo
    └── DashboardSummaryVO.java
```

已实现接口：

```text
GET /api/dashboard/summary
```

文件说明：

| 文件 | 作用 |
| --- | --- |
| `controller/DashboardController.java` | 首页统计 REST API 入口 |
| `service/DashboardService.java` | 首页统计业务接口 |
| `service/impl/DashboardServiceImpl.java` | 首页统计业务实现 |
| `vo/DashboardSummaryVO.java` | 首页统计返回对象 |
| `vo/LogBriefVO.java` | 首页最近异常日志、最近维护记录使用的简略日志对象 |

## 7. 枚举接口模块

枚举接口模块负责给前端下拉框提供固定选项。

目录树：

```text
backend/src/main/java/com/aiot/log
├── controller
│   └── EnumController.java
└── vo
    └── EnumOptionVO.java
```

已实现接口：

```text
GET /api/enums
```

文件说明：

| 文件 | 作用 |
| --- | --- |
| `controller/EnumController.java` | 枚举 REST API 入口 |
| `vo/EnumOptionVO.java` | 枚举选项返回对象 |

## 8. 怎么判断一个文件属于哪个模块

判断规则：

- `Device*` 开头或包含 `Device` 的文件，通常属于设备管理模块。
- `Log*` 开头或包含 `Log` 的文件，通常属于日志管理模块。
- `Tag*` 开头或包含 `Tag` 的文件，通常属于标签管理模块。
- `Dashboard*` 开头的文件，属于首页统计模块。
- `Enum*` 开头的文件，属于枚举接口模块。
- `common`、`config`、`exception` 目录通常是公共基础模块。

注意：

- 有些文件会被多个模块使用，例如 `LogBriefVO` 会被设备详情和首页统计复用。
- `TagVO` 当前由日志返回对象引用，但真正的标签管理模块尚未实现。
