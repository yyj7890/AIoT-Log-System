# AIoT 智能设备运行日志管理系统 - 文档索引

> Docker 一键部署文档：`docker-deployment-guide.md`。该文档说明容器启动、停止、端口、真实设备连接和安全限制。

本文档用于说明 `docs` 目录下每份文档的用途，避免文档过多后职责混乱。

## 1. 文档总览

| 文档 | 用途 | 维护时机 |
| --- | --- | --- |
| `phase-1-requirements.md` | 第一阶段需求文档，说明要做什么 | 需求变化时更新 |
| `database-design.md` | 数据库设计，说明表结构和字段含义 | 表结构变化时更新 |
| `backend-api-design.md` | 后端接口设计，说明 API 路径、参数、响应 | 接口变化时更新 |
| `frontend-page-design.md` | 前端页面设计，说明页面、路由、组件、交互 | 前端页面变化时更新 |
| `mqtt-reporting-guide.md` | MQTT 设备上报说明，说明真实设备连接、topic、JSON 和排查方式 | MQTT 上报协议或连接方式变化时更新 |
| `future-development-backlog.md` | 后续开发归档，说明暂停期间不做但后续需要补强的内容 | 项目暂停、恢复开发或展示目标变化时更新 |
| `project-status.md` | 当前项目进度，说明已经完成什么、下一步做什么 | 每个阶段完成或关键能力变化时更新 |
| `backend-implementation-plan.md` | 后端实现路线，说明按什么顺序写代码 | 后端开发计划变化时更新 |
| `backend-module-map.md` | 后端模块文件地图，说明每个模块对应哪些文件 | 新增模块或文件迁移时更新 |
| `technical-decisions.md` | 技术决策记录，说明为什么用某个技术或版本 | 技术选型变化时更新 |
| `development-log.md` | 开发日志，记录实际过程、报错、修复、验证结果 | 每次遇到问题或完成关键步骤时更新 |

## 2. 阅读顺序

如果是第一次了解项目，建议按这个顺序阅读：

1. `phase-1-requirements.md`
2. `database-design.md`
3. `backend-api-design.md`
4. `frontend-page-design.md`
5. `backend-implementation-plan.md`
6. `project-status.md`
7. `backend-module-map.md`
8. `technical-decisions.md`
9. `development-log.md`

如果是继续开发，只需要看：

1. `backend-implementation-plan.md`
2. `project-status.md`
3. `backend-module-map.md`
4. `development-log.md`
5. 当前要改模块对应的设计文档

## 3. 重复内容整理规则

当前文档中有少量重复内容，主要是为了让单份文档也能独立阅读。后续按以下规则维护：

- 需求只写在 `phase-1-requirements.md`。
- 数据库字段只写在 `database-design.md`，SQL 脚本写在 `sql` 目录。
- API 路径、参数、响应只写在 `backend-api-design.md`。
- 页面、路由、组件只写在 `frontend-page-design.md`。
- 当前项目完成度只写在 `project-status.md`。
- 后端开发顺序只写在 `backend-implementation-plan.md`。
- 后端模块和文件归属只写在 `backend-module-map.md`。
- 技术版本和选型原因只写在 `technical-decisions.md`。
- 报错、修复过程、实际执行结果只写在 `development-log.md`。

## 4. 当前状态

已完成：

- 第一阶段需求设计、数据库设计、后端 API 设计、前端页面设计
- MySQL 本地数据库和初始化数据
- Spring Boot 3 后端基础项目
- 设备、日志、标签、首页统计、枚举接口
- Vue 3 + TypeScript + Element Plus 前端基础页面
- 前后端真实数据库联调
- 一键启动脚本 `start-all.cmd`
- 第二阶段设备自动上报首版：HTTP 上报、MQTT 上报、上报趋势图、告警规则配置
- 本机 Mosquitto MQTT Broker 已完成真实发布订阅联调
- MQTT 状态接口和前端状态页面

当前入口：

```text
D:\AI\IOT\start-all.cmd
```

下一步：

- 项目业务开发暂停，等待真实设备项目完成；后续内容已归档到 `future-development-backlog.md`。

详细进度见：

```text
docs/project-status.md
```
