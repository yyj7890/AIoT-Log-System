# AIoT 智能设备运行日志管理系统 - 技术决策记录

## 1. 后端 Java 版本

最终选择：

- JDK 17

原因：

- 本机已安装 JDK 17，路径为 `C:\Program Files\Java\jdk-17`。
- Spring Boot 3 要求 Java 17 或更高版本。
- JDK 17 是长期支持版本，适合课程项目、简历项目和后续扩展。

本机检查结果：

```text
java version "17.0.12" 2024-07-16 LTS
javac 17.0.12
```

注意：

- 当前系统默认 `java` 命令仍指向 Java 8。
- 如需运行 Spring Boot 3 后端，需要将 `JAVA_HOME` 指向 JDK 17。

PowerShell 临时切换方式：

```powershell
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
java -version
```

## 2. 后端 Spring Boot 版本

最终选择：

- Spring Boot 3.3.5

原因：

- Spring Boot 3 是当前更现代的主流版本。
- 项目刚开始，切换成本低。
- 配合 JDK 17 更适合长期维护和简历展示。

影响：

- 校验相关包使用 `jakarta.validation.*`。
- 不再使用 Spring Boot 2 中常见的 `javax.validation.*`。

示例：

```java
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
```

## 3. 后端 ORM 方案

最终选择：

- MyBatis Plus
- `mybatis-plus-spring-boot3-starter`

原因：

- 适合 Spring Boot + MySQL 项目。
- 能减少基础 CRUD 代码。
- 国内课程、实习和企业项目中比较常见。

## 4. 数据库

最终选择：

- MySQL 8.x

原因：

- 与项目规划一致。
- 适合设备、日志、标签这类结构化业务数据。
- 与 Spring Boot、MyBatis Plus 配合成熟。

数据库名：

```text
aiot_log_system
```

## 5. 后端项目结构

当前结构：

```text
backend
├── src/main/java/com/aiot/log
│   ├── common
│   ├── config
│   ├── controller
│   ├── dto
│   ├── entity
│   ├── enums
│   ├── exception
│   ├── mapper
│   ├── service
│   └── vo
└── src/main/resources
```

说明：

- `controller`：REST API 入口。
- `service`：业务逻辑。
- `mapper`：数据库访问。
- `entity`：数据库实体。
- `dto`：请求参数对象。
- `vo`：响应对象。
- `common`：统一响应、分页结果等公共结构。
- `exception`：业务异常和全局异常处理。
- `config`：框架配置。

## 6. Maven 状态

当前状态：

- 已在项目目录安装 Maven 3.9.16。

安装位置：

```text
D:\AI\IOT\tools\apache-maven-3.9.16
```

验证结果：

```text
Apache Maven 3.9.16
Maven home: D:\AI\IOT\tools\apache-maven-3.9.16
Java version: 17.0.12
```

说明：

- Maven 没有安装到系统全局目录。
- 当前采用项目本地 Maven，避免修改系统环境变量。
- 每次命令行运行后端时，需要临时把 JDK 17 和 Maven 加入当前 PowerShell 会话的 `Path`。

推荐：

- 后续如果想全局使用 `mvn`，可以再配置系统环境变量。

运行命令：

```powershell
cd D:\AI\IOT\backend
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;D:\AI\IOT\tools\apache-maven-3.9.16\bin;$env:Path"
mvn spring-boot:run
```

## 7. 当前已实现范围

已完成：

- Spring Boot 3 后端基础项目
- MySQL 连接配置
- MyBatis Plus 配置
- 跨域配置
- 统一 API 响应
- 全局异常处理
- 设备管理接口
- 后端首次编译验证通过

已实现设备接口：

```text
GET    /api/devices
GET    /api/devices/{id}
POST   /api/devices
PUT    /api/devices/{id}
DELETE /api/devices/{id}
```

未完成：

- 日志管理接口
- 标签管理接口
- 首页统计接口
- 枚举接口
- 前端项目

## 8. 编译验证记录

2026-07-06 首次后端编译通过。

编译命令：

```powershell
cd D:\AI\IOT\backend
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;D:\AI\IOT\tools\apache-maven-3.9.16\bin;$env:Path"
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

结果：

```text
BUILD SUCCESS
Compiling 19 source files with javac [debug parameters release 17]
```

详细开发过程、报错和修复记录见：

```text
docs/development-log.md
```

早期后端实现顺序已完成，历史文档见：

```text
docs/archive/backend-implementation-plan.md
```

## 9. 2026-07-07 本地运行决策补充

### 9.1 MySQL 本地运行方式

当前采用本机 MySQL Server 8.4.9。

安装目录：

```text
C:\Program Files\MySQL\MySQL Server 8.4
```

项目本地数据目录：

```text
D:\AI\IOT\mysql-data
```

原因：

- 数据库文件放在项目目录下，便于记录和迁移当前实验环境。
- 不依赖 Windows 服务注册，适合开发阶段快速启动和停止。

当前启动命令：

```powershell
Start-Process -FilePath 'C:\Program Files\MySQL\MySQL Server 8.4\bin\mysqld.exe' -ArgumentList '--basedir="C:\Program Files\MySQL\MySQL Server 8.4" --datadir="D:\AI\IOT\mysql-data" --port=3306 --bind-address=127.0.0.1' -WindowStyle Hidden
```

### 9.2 JDBC URL 参数

当前 Spring Boot 数据库连接 URL：

```text
jdbc:mysql://localhost:3306/aiot_log_system?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true
```

新增 `allowPublicKeyRetrieval=true` 的原因：

- MySQL 8 默认认证方式使用 `caching_sha2_password`。
- 本地开发环境使用 root/root 连接时，JDBC 可能报错 `Public Key Retrieval is not allowed`。
- 加上该参数后，数据库接口可以正常连接。

### 9.3 后端启动方式

当前真实联调优先使用：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml spring-boot:run
```

说明：

- `spring-boot:run` 是长驻命令，启动成功后不会自动退出。
- 在工具环境中应使用后台进程启动，并通过日志和端口判断状态。
- `mvn package` 当前在 Windows 上遇到 jar 重命名失败，暂不作为主要启动路径。

### 9.4 当前后端接口状态

截至 2026-07-07，以下接口已完成真实 MySQL 联调：

```text
GET  /api/enums
GET  /api/dashboard/summary
GET  /api/logs?page=1&pageSize=3
GET  /api/tags
POST /api/tags
```

结果均为：

```text
HTTP 200 / code 200
```

## 10. 2026-07-07 前端技术决策

前端采用：

```text
Vue 3 + TypeScript + Vite
Vue Router
Pinia
Element Plus
Axios
@element-plus/icons-vue
```

原因：

- 与项目文档中的前端设计一致。
- Vue 3 + Vite 适合快速搭建管理系统。
- Element Plus 提供表格、表单、弹窗、标签、分页等后台管理常用组件。
- Axios 统一封装后端 API 调用。
- Pinia 当前用于维护枚举缓存，后续可以扩展用户、权限或全局配置状态。

本地开发端口：

```text
5173
```

后端代理：

```text
/api -> http://127.0.0.1:8080
```

当前构建命令：

```powershell
cd D:\AI\IOT\frontend
npm run build
```

验证结果：

```text
BUILD SUCCESS
```

## 11. 2026-07-07 一键启动方式

当前采用根目录脚本统一启动开发环境：

```text
start-all.ps1
start-all.cmd
```

选择原因：

- 开发阶段需要同时启动 MySQL、后端和前端。
- 手动分别输入三组命令容易出错。
- 一键脚本可以先检查端口，避免重复启动服务。
- 当前不改变前后端项目结构，适合开发联调阶段。

脚本检查端口：

```text
MySQL   3306
Backend 8080
Frontend 5173
```

脚本最终打开：

```text
http://127.0.0.1:5173/
```

后续如果进入部署阶段，可以再改成：

```text
前端 build 后放入后端静态资源，只启动一个 Spring Boot 服务。
```

## 12. 2026-07-08 当前技术栈展示判断

当前技术栈：

```text
前端：Vue 3 + TypeScript + Vite + Element Plus
后端：Spring Boot 3.3.5 + MyBatis Plus
数据库：MySQL 8.4
设备上报：HTTP + MQTT
MQTT Broker：Mosquitto
```

判断：

- 该技术栈不落后，适合作为 Java 后端、全栈或 IoT 管理系统作品展示。
- Spring Boot 3 + Java 17 是现代 Java 后端组合。
- Vue 3 + TypeScript + Element Plus 适合后台管理系统。
- MySQL、MyBatis Plus、Docker、Redis、Nginx、JWT 等是国内 Java 岗位常见组合。
- MQTT / Mosquitto 能体现 IoT 场景，不是普通 CRUD 项目的重复堆叠。

后续补强项不在本文档展开，统一归档到：

```text
docs/future-development-backlog.md
```
