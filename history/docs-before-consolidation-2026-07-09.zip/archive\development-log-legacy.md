# AIoT 智能设备运行日志管理系统 - 开发记录

## 2026-07-09 Docker 启动时页面 502 修复

- 原 `docker-start.cmd` 只检查 Nginx 首页，Nginx 通常早于 Spring Boot 后端就绪。
- 浏览器过早打开后，首页 API 请求会经过 Nginx 访问尚未就绪的后端并返回 `502`。
- 启动脚本已改为先轮询后端首页统计接口，再检查前端，全部就绪后才打开浏览器。

## 2026-07-09 Docker 初始化中文乱码修复

- 页面固定文字正常，但 Docker 首次初始化的设备、标签和日志数据出现乱码。
- SQL 文件内容确认是正确 UTF-8，乱码数据可通过单字节编码反向转换恢复。
- 已原地修复当前 Docker MySQL 数据，不删除数据库卷和现有记录。
- `schema.sql` 和 `init-data.sql` 增加 `SET NAMES utf8mb4`，避免新数据库初始化再次错误解释中文。
- JDBC 连接显式使用 Java UTF-8 字符集，数据库与初始化脚本使用 `utf8mb4`。
- 后端 Servlet 响应显式强制 UTF-8，改善未按 JSON 默认 UTF-8 解码的客户端兼容性。

## 2026-07-09 Docker Compose 完整验收

- 四个容器均成功启动：frontend、backend、mysql、mosquitto。
- MySQL 状态为 `healthy`。
- 网页、后端接口和 MQTT 状态接口验证通过。
- MQTT 后端订阅连接状态为正常。
- 将日常启动与更新构建拆分为 `docker-start.cmd` 和 `docker-update.cmd`，减少后续启动耗时。

## 2026-07-09 Docker Maven 依赖下载中断修复

- 后端 Docker 构建已进入 Maven 依赖下载阶段。
- 原构建从 Maven Central 下载依赖时出现 `Premature end of Content-Length`，属于传输中断。
- 新增 `backend/maven-settings-docker.xml`，Docker 构建改用国内 Maven 公共镜像。
- Dockerfile 增加 Maven 下载重试和 BuildKit 缓存，重新构建时复用已经下载的依赖。

## 2026-07-09 Docker 首次构建网络问题

- 已安装 Docker Desktop，并确认 WSL 2 默认版本为 2。
- Docker Desktop 已配置本机 VPN HTTP/HTTPS 代理。
- `mysql:8.4`、`eclipse-mosquitto:2`、`maven:3.9.9-eclipse-temurin-17`、`node:22-alpine` 和 `nginx:1.27-alpine` 已拉取成功。
- 当前只剩 `eclipse-temurin:17-jre` 基础镜像未完成拉取。
- Docker Compose 构建过程中多次在 Docker Hub 鉴权或镜像下载阶段出现超时、`unexpected EOF`。
- 当前报错集中在 `auth.docker.io`，属于网络和代理稳定性问题，不是项目 Dockerfile 编译错误。
- 本次暂停继续下载，将剩余基础镜像、完整容器联调和国内镜像仓库发布纳入后续计划。

## 2026-07-09 Docker Compose 一键部署

- 新增 `docker-compose.yml`，编排 MySQL、Mosquitto、Spring Boot 后端和 Vue/Nginx 前端。
- 新增前后端多阶段 Dockerfile与 Nginx `/api` 反向代理。
- 新增 Mosquitto 容器配置，开放局域网 MQTT `1883` 端口用于真实设备联调。
- 新增 `docker-start.cmd` 和 `docker-stop.cmd`。
- 后端数据库和 MQTT 地址改为环境变量覆盖，默认值继续兼容本地开发。
- 新增 `docs/docker-deployment-guide.md` 和根目录 `README.md`。
- 当前匿名 MQTT 仅用于可信局域网联调，正式部署前需增加认证和 TLS。

本文档用于记录项目开发过程，包括技术栈、搭建流程、关键决策、报错信息、原因分析和修复方式。

## 1. 当前技术栈

### 1.1 后端

| 项目 | 选择 |
| --- | --- |
| Java | JDK 17 |
| Spring Boot | 3.3.5 |
| ORM | MyBatis Plus |
| 数据库 | MySQL 8.x |
| 构建工具 | Maven 3.9.16 |
| API 风格 | REST API |

### 1.2 前端

前端尚未搭建，设计阶段暂定：

| 项目 | 选择 |
| --- | --- |
| 框架 | Vue 3 |
| 语言 | TypeScript |
| UI 组件库 | Element Plus |
| 路由 | Vue Router |
| 状态管理 | Pinia |
| HTTP 请求 | Axios |

### 1.3 数据库

| 项目 | 选择 |
| --- | --- |
| 数据库 | MySQL |
| 数据库名 | `aiot_log_system` |
| 字符集 | `utf8mb4` |
| 排序规则 | `utf8mb4_0900_ai_ci` |

## 2. 当前目录结构

```text
D:\AI\IOT
├── backend
├── docs
├── sql
└── tools
```

说明：

- `backend`：Spring Boot 后端项目。
- `docs`：需求、设计、技术决策和开发记录。
- `sql`：数据库建表和初始化数据脚本。
- `tools`：项目本地开发工具，例如 Maven。

## 3. 已完成流程

### 3.1 项目上下文读取

读取项目上下文文档：

```text
C:\Users\yang\Documents\Codex\2026-07-06\kan\outputs\aiot-log-project-context.md
```

明确项目分为三个阶段：

- 第一阶段：基础可用版，完成设备管理、日志管理、标签筛选和首页统计。
- 第二阶段：加入物联网特色，增加传感器数据、设备自动上报、异常自动记录。
- 第三阶段：加入 AI 亮点，增加日志总结、异常分析和维护建议。

### 3.2 第一阶段需求文档

已创建：

```text
docs/phase-1-requirements.md
```

内容包括：

- 设备管理需求
- 日志管理需求
- 标签筛选需求
- 首页统计需求
- 页面结构
- 枚举定义
- 验收标准

### 3.3 数据库设计

已创建：

```text
docs/database-design.md
sql/schema.sql
sql/init-data.sql
```

核心表：

- `users`
- `devices`
- `logs`
- `tags`
- `log_tags`

说明：

- `sql/init-data.sql` 中的数据是演示数据，不代表本地已有真实设备。
- 演示数据用于后续开发页面和测试接口。

### 3.4 后端 API 设计

已创建：

```text
docs/backend-api-design.md
```

已设计模块：

- 首页统计 API
- 设备 API
- 日志 API
- 标签 API
- 枚举 API

### 3.5 前端页面设计

已创建：

```text
docs/frontend-page-design.md
```

已设计页面：

- `/dashboard`
- `/devices`
- `/devices/:id`
- `/logs`
- `/tags`

### 3.6 后端基础项目搭建

已创建：

```text
backend
```

后端基础结构：

```text
backend/src/main/java/com/aiot/log
├── common
├── config
├── controller
├── dto
├── entity
├── enums
├── exception
├── mapper
├── service
└── vo
```

已实现：

- Spring Boot 启动类
- 统一响应结构
- 分页结果结构
- 全局异常处理
- MyBatis Plus 分页配置
- 跨域配置
- 设备管理接口

设备接口：

```text
GET    /api/devices
GET    /api/devices/{id}
POST   /api/devices
PUT    /api/devices/{id}
DELETE /api/devices/{id}
```

## 4. 技术决策记录

### 4.1 从 Spring Boot 2 切换到 Spring Boot 3

最初为了兼容系统默认 Java 8，后端先按 Spring Boot 2.7.18 搭建。

之后检查本机 Java 环境，发现已安装 JDK 17：

```text
C:\Program Files\Java\jdk-17
```

验证结果：

```text
java version "17.0.12" 2024-07-16 LTS
javac 17.0.12
```

因此切换到：

```text
Spring Boot 3.3.5
JDK 17
```

修改内容：

- `pom.xml` 中 Spring Boot 版本改为 `3.3.5`。
- `java.version` 改为 `17`。
- MyBatis Plus 改为 `mybatis-plus-spring-boot3-starter`。
- MySQL 驱动改为 `com.mysql:mysql-connector-j`。
- `javax.validation.*` 改为 `jakarta.validation.*`。

### 4.2 Maven 使用项目本地安装

系统没有全局 Maven：

```text
mvn : The term 'mvn' is not recognized
```

处理方式：

- 下载 Apache Maven 3.9.16。
- 解压到项目目录：

```text
D:\AI\IOT\tools\apache-maven-3.9.16
```

原因：

- 不修改系统环境变量。
- 项目内即可复现构建环境。

## 5. 报错记录

### 5.1 PowerShell 读取上下文文档出现中文乱码

现象：

第一次读取上下文文档时中文显示乱码。

原因：

PowerShell 默认编码与文档实际编码不一致。

解决方式：

改用 UTF-8 读取：

```powershell
Get-Content -LiteralPath 'C:\Users\yang\Documents\Codex\2026-07-06\kan\outputs\aiot-log-project-context.md' -Raw -Encoding UTF8
```

结果：

文档内容正常显示。

### 5.2 Maven 命令不存在

现象：

执行：

```powershell
mvn -version
```

报错：

```text
mvn : The term 'mvn' is not recognized as the name of a cmdlet, function, script file, or operable program.
```

原因：

本机没有安装全局 Maven，或 Maven 没有配置到系统 `Path`。

解决方式：

下载 Apache Maven 3.9.16 到项目目录：

```text
D:\AI\IOT\tools\apache-maven-3.9.16
```

通过临时环境变量使用 Maven：

```powershell
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;D:\AI\IOT\tools\apache-maven-3.9.16\bin;$env:Path"
mvn -version
```

结果：

```text
Apache Maven 3.9.16
Java version: 17.0.12
```

### 5.3 winget 找不到 Apache Maven 包

现象：

执行：

```powershell
winget install --id Apache.Maven --exact --accept-package-agreements --accept-source-agreements
```

报错：

```text
找不到与输入条件匹配的程序包。
```

原因：

当前 winget 源中没有匹配 `Apache.Maven` 的包。

解决方式：

改为从 Apache Maven 官方下载 ZIP 包并解压到项目目录。

下载来源：

```text
https://dlcdn.apache.org/maven/maven-3/3.9.16/binaries/apache-maven-3.9.16-bin.zip
```

结果：

Maven 安装成功。

### 5.4 Maven 默认本地仓库无法创建

现象：

执行首次编译：

```powershell
mvn clean compile
```

报错：

```text
Could not create local repository at C:\Users\yang\.m2\repository
```

原因：

当前执行环境不能写入默认用户目录下的 Maven 本地仓库路径。

解决方式：

新增项目内 Maven 配置：

```text
tools/maven-settings.xml
```

内容指定本地仓库：

```xml
<localRepository>D:\AI\IOT\.m2\repository</localRepository>
```

然后编译时指定 settings：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

结果：

Maven 使用项目内 `.m2/repository` 作为本地仓库。

### 5.5 Maven 首次下载依赖失败

现象：

使用项目本地 Maven 仓库后，Maven 开始下载依赖，但首次下载 Spring Boot parent POM 失败。

报错核心：

```text
Non-resolvable parent POM
Could not transfer artifact org.springframework.boot:spring-boot-starter-parent:pom:3.3.5
```

原因：

首次 Maven 编译需要访问 Maven Central 下载依赖，普通沙箱环境下载过程不稳定或受限。

解决方式：

使用联网权限重新执行编译：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

结果：

依赖下载成功，后端编译通过。

### 5.6 后端首次编译验证

编译命令：

```powershell
cd D:\AI\IOT\backend
$env:JAVA_HOME='C:\Program Files\Java\jdk-17'
$env:Path="$env:JAVA_HOME\bin;D:\AI\IOT\tools\apache-maven-3.9.16\bin;$env:Path"
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

结果：

```text
BUILD SUCCESS
Compiling 19 source files with javac [debug parameters release 17]
```

结论：

当前后端基础项目和设备管理接口代码可以通过编译。

### 5.7 Maven clean 删除 target 文件失败

现象：

实现日志管理接口后，执行：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml clean compile
```

报错：

```text
Failed to clean project: Failed to delete D:\AI\IOT\backend\target\maven-status\maven-compiler-plugin\compile\default-compile\inputFiles.lst
```

原因：

`target` 目录中的编译状态文件被进程占用或文件系统暂时锁定，导致 Maven clean 阶段无法删除。

处理方式：

本次目标是验证新增源码是否能编译，因此改用不删除 `target` 的编译命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml compile
```

结果：

源码编译通过。

后续处理：

- 如果再次需要完整 clean，可关闭 IDE、终端中可能占用 `target` 的进程后重试。
- 必要时再手动清理 `backend/target`。

### 5.8 日志管理接口第一版编译验证

已实现接口：

```text
GET    /api/logs
GET    /api/logs/{id}
POST   /api/logs
PUT    /api/logs/{id}
PATCH  /api/logs/{id}/status
DELETE /api/logs/{id}
```

已实现能力：

- 新增日志。
- 查询日志列表。
- 查看日志详情。
- 编辑日志。
- 修改日志状态。
- 删除日志。
- 按设备、日志类型、日志等级、处理状态、关键词、时间范围筛选。

暂未实现：

- 日志标签关联。
- 按标签筛选日志。

原因：

标签模块尚未实现。当前 DTO 中已保留 `tagIds` 字段，后续实现标签模块后接入。

编译命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml compile
```

结果：

```text
BUILD SUCCESS
Compiling 30 source files with javac [debug parameters release 17]
```

### 5.9 标签管理接口和日志标签关联编译验证

已实现标签接口：

```text
GET    /api/tags
POST   /api/tags
DELETE /api/tags/{id}
```

新增文件：

```text
entity/Tag.java
entity/LogTag.java
mapper/TagMapper.java
mapper/LogTagMapper.java
dto/TagCreateRequest.java
service/TagService.java
service/impl/TagServiceImpl.java
controller/TagController.java
```

已修改：

```text
service/impl/LogServiceImpl.java
```

已实现能力：

- 查询标签列表。
- 新增标签。
- 删除标签。
- 新增日志时保存 `tagIds`。
- 编辑日志时更新 `tagIds`。
- 查询日志时返回标签列表。
- 日志列表支持 `tagId` 筛选。
- 删除日志时主动删除日志标签关联。
- 删除标签时主动删除日志标签关联。

编译命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml compile
```

结果：

```text
BUILD SUCCESS
Compiling 38 source files with javac [debug parameters release 17]
```

### 5.10 首页统计接口编译验证

已实现接口：

```text
GET /api/dashboard/summary
```

新增文件：

```text
vo/DashboardSummaryVO.java
service/DashboardService.java
service/impl/DashboardServiceImpl.java
controller/DashboardController.java
```

已修改：

```text
vo/LogBriefVO.java
service/impl/DeviceServiceImpl.java
```

已实现能力：

- 设备总数统计。
- 正常设备数统计。
- 异常设备数统计。
- 离线设备数统计。
- 维护中设备数统计。
- 待处理日志数统计。
- 最近异常日志。
- 最近维护记录。

编译命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml compile
```

结果：

```text
BUILD SUCCESS
Compiling 42 source files with javac [debug parameters release 17]
```

### 5.11 枚举接口编译验证

已实现接口：

```text
GET /api/enums
```

新增文件：

```text
vo/EnumOptionVO.java
controller/EnumController.java
```

已实现能力：

- 返回设备状态枚举。
- 返回日志类型枚举。
- 返回日志等级枚举。
- 返回日志处理状态枚举。

编译命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml compile
```

结果：

```text
BUILD SUCCESS
Compiling 44 source files with javac [debug parameters release 17]
```

## 6. 当前待办

该阶段后端实现路线已经完成，历史计划保留在：

```text
docs/archive/backend-implementation-plan.md
```

当前待办以 `docs/future-development-backlog.md` 为准。
3. 搭建前端项目。

前端待办：

1. 搭建 Vue 3 + TypeScript + Element Plus 项目。
2. 创建基础布局。
3. 实现设备管理页面。
4. 接入后端设备接口。
5. 实现日志、标签、首页统计页面。

## 7. 2026-07-07 后端连接 MySQL 与接口验证记录

### 7.1 启动卡住的原因

现象：

- 执行后端启动命令后，界面长时间没有返回。
- 多次看起来像“卡住”。

实际原因：

- `spring-boot:run` 和 `java -jar` 都是长驻服务命令，服务启动成功后会一直占用前台等待 HTTP 请求。
- 这类命令不应该用普通前台执行方式验证，否则工具会一直等待进程结束。

处理方式：

- 改为使用 `Start-Process` 后台启动。
- 后端标准输出写入 `backend/backend-run.log`。
- 后端错误输出写入 `backend/backend-run.err.log`。
- 用 `netstat -ano | Select-String ':8080'` 判断后端是否监听端口。

### 7.2 MySQL 启动问题

本机 MySQL 版本：

```text
MySQL Server 8.4.9
```

安装目录：

```text
C:\Program Files\MySQL\MySQL Server 8.4
```

项目本地数据目录：

```text
D:\AI\IOT\mysql-data
```

遇到的问题：

1. `Start-Process` 参数中 `C:\Program Files\...` 没有正确加引号时，MySQL 把路径拆成了多个参数。
2. 错误日志出现 `Too many arguments (first extra is 'Files\MySQL\MySQL')`。
3. 修复方式是把 `--basedir` 和 `--datadir` 的值用双引号包起来。

可用启动命令：

```powershell
Start-Process -FilePath 'C:\Program Files\MySQL\MySQL Server 8.4\bin\mysqld.exe' -ArgumentList '--basedir="C:\Program Files\MySQL\MySQL Server 8.4" --datadir="D:\AI\IOT\mysql-data" --port=3306 --bind-address=127.0.0.1' -WindowStyle Hidden
```

验证结果：

```text
127.0.0.1:3306 LISTENING
```

### 7.3 JDBC 连接问题

现象：

- `/api/enums` 正常返回 200。
- `/api/dashboard/summary`、`/api/logs`、`/api/tags` 返回 500。

原因：

```text
Public Key Retrieval is not allowed
```

这是 MySQL 8 默认认证方式和 JDBC URL 配置不完整导致的本地连接问题。

修复文件：

```text
backend/src/main/resources/application.yml
```

修复内容：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/aiot_log_system?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true
```

### 7.4 Maven 打包问题

命令：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml -DskipTests package
```

结果：

```text
BUILD FAILURE
Unable to rename 'D:\AI\IOT\backend\target\aiot-log-backend-0.0.1-SNAPSHOT.jar'
to 'D:\AI\IOT\backend\target\aiot-log-backend-0.0.1-SNAPSHOT.jar.original'
```

判断：

- 这是 Windows 下 jar 文件重命名被占用或被系统短暂锁定导致的问题。
- 当前不影响用 `spring-boot:run` 启动和接口验证。
- 后续需要稳定 jar 发布时，再单独处理打包流程。

### 7.5 本次接口验证结果

后端启动方式：

```powershell
mvn -s D:\AI\IOT\tools\maven-settings.xml spring-boot:run
```

监听结果：

```text
0.0.0.0:8080 LISTENING
```

已验证接口：

```text
GET  /api/enums                  200
GET  /api/dashboard/summary      200
GET  /api/logs?page=1&pageSize=3 200
GET  /api/tags                   200
POST /api/tags                   200
```

新增标签测试数据：

```json
{
  "name": "api-test",
  "color": "#409EFF"
}
```

返回结果：

```text
code = 200
id = 9
```

当前状态：

- MySQL 已正常启动。
- Spring Boot 后端已正常启动。
- 第一阶段后端核心接口已完成首次真实数据库联调。
- 下一步可以开始搭建前端项目。

## 8. 2026-07-07 前端项目搭建记录

### 8.1 技术栈

前端采用：

```text
Vue 3
TypeScript
Vite
Vue Router
Pinia
Element Plus
Axios
@element-plus/icons-vue
```

本机版本：

```text
Node.js v24.16.0
npm 11.13.0
```

前端目录：

```text
D:\AI\IOT\frontend
```

### 8.2 已创建目录和文件

核心文件：

```text
frontend/package.json
frontend/index.html
frontend/vite.config.ts
frontend/tsconfig.json
frontend/tsconfig.node.json
frontend/src/main.ts
frontend/src/App.vue
frontend/src/styles.css
```

模块目录：

```text
frontend/src/api
frontend/src/components
frontend/src/layouts
frontend/src/router
frontend/src/stores
frontend/src/types
frontend/src/views
```

已实现页面：

```text
/dashboard
/devices
/devices/:id
/logs
/tags
```

### 8.3 API 代理配置

文件：

```text
frontend/vite.config.ts
```

配置：

```ts
server: {
  port: 5173,
  proxy: {
    '/api': {
      target: 'http://127.0.0.1:8080',
      changeOrigin: true
    }
  }
}
```

验证结果：

```text
http://127.0.0.1:5173/                     200
http://127.0.0.1:5173/api/enums            code=200
http://127.0.0.1:5173/api/dashboard/summary code=200
```

### 8.4 依赖安装问题

第一次执行：

```powershell
npm install
```

失败原因：

```text
cache mode is 'only-if-cached' but no cached response is available
```

判断：

- 沙箱环境不能直接从 npm registry 下载未缓存依赖。

处理：

- 使用非沙箱网络权限重新执行 `npm install`。

结果：

```text
added 102 packages
found 0 vulnerabilities
```

后续新增 `@types/node` 后再次安装：

```text
added 2 packages
found 0 vulnerabilities
```

### 8.5 构建问题和修复

第一次执行：

```powershell
npm run build
```

问题 1：

```text
Cannot find name 'Map'
Cannot find name 'Set'
Cannot find type definition file for 'node'
```

修复：

- 新增开发依赖 `@types/node`。
- 在 `tsconfig.node.json` 中补充：

```json
{
  "target": "ES2020",
  "lib": ["ES2020", "WebWorker"],
  "types": ["node"]
}
```

问题 2：

```text
Parameter 'status' implicitly has an 'any' type
```

修复：

- 将日志状态下拉菜单的内联处理函数改为显式函数 `handleStatusCommand`。

问题 3：

```text
Error: spawn EPERM
```

原因：

- Vite 构建时需要启动 esbuild 子进程，沙箱环境拒绝该进程。

处理：

- 使用非沙箱权限执行 `npm run build`。

最终构建结果：

```text
vue-tsc --noEmit --incremental false && vite build
BUILD SUCCESS
```

### 8.6 页面联调验证

前端开发服务器：

```text
http://127.0.0.1:5173/
```

浏览器验证结果：

```text
/dashboard   正常显示统计卡片、最近异常日志、最近维护记录
/devices     正常显示设备列表
/logs        正常显示日志列表和筛选项
/tags        正常显示标签列表
/devices/1   正常显示设备详情和最近日志
```

控制台结果：

```text
无前端业务错误
```

当前状态：

- 前端基础项目已搭建完成。
- 第一阶段主要页面已创建。
- 前端已通过 Vite 代理接入后端接口。
- 前端生产构建已通过。

## 9. 2026-07-07 一键启动脚本记录

新增文件：

```text
start-all.ps1
start-all.cmd
docs/project-status.md
```

一键启动入口：

```text
D:\AI\IOT\start-all.cmd
```

脚本行为：

1. 检查 `127.0.0.1:3306`，如果 MySQL 未运行则启动 MySQL。
2. 检查 `127.0.0.1:8080`，如果后端未运行则启动 Spring Boot。
3. 检查 `127.0.0.1:5173`，如果前端未运行则启动 Vite。
4. 自动打开浏览器访问 `http://127.0.0.1:5173/`。

浏览器打开方式：

```powershell
cmd /c start "" "http://127.0.0.1:5173/"
```

说明：

- 最初使用 `Start-Process $FrontendUrl`，在部分 Windows/PowerShell 环境下可能静默不打开默认浏览器。
- 已改为通过 `cmd /c start` 调用系统默认浏览器，更适合双击 `.cmd` 使用。

测试命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File D:\AI\IOT\start-all.ps1 -NoBrowser
D:\AI\IOT\start-all.cmd
```

测试结果：

```text
MySQL already running on 127.0.0.1:3306
Backend already running on 127.0.0.1:8080
Frontend already running on 127.0.0.1:5173
Opening http://127.0.0.1:5173/
All services are ready.
```

当前项目进度说明已整理到：

```text
docs/project-status.md
```

## 10. 2026-07-07 第一阶段演示流程验收

用户已完成前端页面人工测试，测试项如下：

```text
新增设备      通过
新增日志      通过
日志筛选      通过
修改日志状态  通过
新增标签      通过
删除标签      通过
```

验收结论：

```text
第一阶段基础可用版主要功能通过人工验收。
```

当前阶段：

```text
第一阶段进入收尾状态，后续可以准备第二阶段设备自动上报能力。
```

## 11. 2026-07-07 第二阶段设备自动上报首版

本次目标：

```text
实现 HTTP 设备上报接口、模拟设备上报脚本、异常自动生成日志，并在设备详情页展示最近上报数据。
```

新增数据库表：

```text
device_reports
```

新增后端接口：

```text
POST /api/device-reports
GET  /api/device-reports
```

新增后端文件：

```text
entity/DeviceReport.java
dto/DeviceReportCreateRequest.java
vo/DeviceReportVO.java
mapper/DeviceReportMapper.java
service/DeviceReportService.java
service/impl/DeviceReportServiceImpl.java
controller/DeviceReportController.java
```

新增前端文件：

```text
frontend/src/types/report.ts
frontend/src/api/reports.ts
```

新增模拟脚本：

```text
tools/simulate-device-report.ps1
```

异常判定首版规则：

```text
status = ABNORMAL
temperature > 80
voltage < 210
signalStrength < -95
```

命中异常规则时：

```text
自动写入 logs 表，log_type=ERROR，level=ERROR，status=PENDING，source=DEVICE。
```

编译验证结果：

```text
后端 mvn compile：BUILD SUCCESS
前端 npm run build：BUILD SUCCESS
```

运行联调结果：

```text
已执行 sql/schema.sql，device_reports 表已创建。
已重启后端服务，8080 正常监听。
GET  /api/device-reports?page=1&pageSize=2：200
GET  /api/devices/2：200，并返回 recentReports 字段。
tools/simulate-device-report.ps1 -Count 3 -IntervalSeconds 1 -IncludeAbnormal：成功写入 3 条上报。
异常上报 reportId=3 自动生成 generatedLogId=10。
GET  /api/logs?page=1&pageSize=3&deviceId=2：返回 source=DEVICE 的异常日志。
```

说明：

- 前端普通沙箱构建仍会因为 Vite/esbuild 子进程出现 `spawn EPERM`，使用非沙箱权限执行后构建成功。
- 模拟脚本默认说明已改为英文 ASCII，避免 Windows PowerShell 编码差异导致测试消息入库乱码。

## 12. 2026-07-08 第二阶段日志来源展示和筛选

本次目标：

```text
让日志模块能区分人工录入、设备上报、系统生成三类来源，并支持按来源筛选。
```

新增后端文件：

```text
backend/src/main/java/com/aiot/log/enums/LogSource.java
```

已修改后端能力：

```text
GET /api/enums 新增 logSource 枚举。
GET /api/logs 新增 source 查询参数。
设备详情 recentLogs 返回 source 字段。
```

已修改前端能力：

```text
日志列表新增“日志来源”筛选项。
日志列表“来源”列改为中文标签展示。
日志详情展示来源。
设备详情最近日志展示来源。
```

验证结果：

```text
后端 mvn compile：BUILD SUCCESS
前端 npm run build：BUILD SUCCESS
```

## 15. 2026-07-08 第二阶段 MQTT 可选接入

本次目标：

```text
在不影响 HTTP 上报的前提下，为后端增加 MQTT 订阅入口。
```

新增依赖：

```text
org.eclipse.paho:org.eclipse.paho.client.mqttv3:1.2.5
```

新增配置：

```yaml
mqtt:
  enabled: false
  broker-url: tcp://127.0.0.1:1883
  client-id: aiot-log-backend
  topic: aiot/device/+/report
  qos: 1
```

新增后端文件：

```text
backend/src/main/java/com/aiot/log/config/MqttProperties.java
backend/src/main/java/com/aiot/log/config/MqttDeviceReportSubscriber.java
```

新增模拟脚本：

```text
tools/simulate-mqtt-report.ps1
```

实现方式：

```text
后端启动后，如果 mqtt.enabled=true，则连接 MQTT Broker 并订阅 aiot/device/+/report。
收到 MQTT 消息后，将 JSON 解析为 DeviceReportCreateRequest。
随后调用 DeviceReportService.createReport()，复用 HTTP 上报的入库、告警规则和异常日志生成逻辑。
```

一键脚本：

```text
start-all.ps1 会检测本机是否安装 Mosquitto。
如果存在 mosquitto.exe，则自动启动 1883 端口的 MQTT Broker。
如果不存在，则跳过 MQTT Broker，不影响 MySQL、后端和前端启动。
stop-all.ps1 会尝试停止 1883 端口上的 MQTT Broker。
```

验证结果：

```text
后端 mvn compile：BUILD SUCCESS
```

当前限制：

```text
本机初始未检测到 Mosquitto，因此第一版提交时尚未做真实 MQTT 发布订阅联调。
后续已安装 Mosquitto 并将 mqtt.enabled 改为 true，完成真实 MQTT 发布订阅验证。
```

## 16. 2026-07-08 MQTT 本地 Broker 联调和脚本修复

本次目标：

```text
使用本机 Mosquitto 验证 MQTT 上报链路，并确认正常上报、异常上报都能进入系统。
```

本机 Mosquitto 安装位置：

```text
C:\Program Files\mosquitto
```

联调现象：

```text
直接运行 mosquitto.exe -v 时提示 1883 端口已占用，说明 MQTT Broker 已经在本机运行。
start-all.ps1 检测到 127.0.0.1:1883 后输出 MQTT broker is ready on 127.0.0.1:1883。
后端启动后订阅 aiot/device/+/report。
```

发现的问题：

```text
第一版 tools/simulate-mqtt-report.ps1 使用 mosquitto_pub -m $json 发布消息。
PowerShell 会影响 JSON 参数传递，导致后端收到的内容缺少双引号，Jackson 无法解析。
表现为命令行显示 Published MQTT report，但后端没有写入 device_reports。
```

修复方式：

```text
simulate-mqtt-report.ps1 改为把 JSON 写入 UTF-8 临时文件，再通过 mosquitto_pub -f 临时文件发布。
同时增加 mosquitto_pub 退出码检查，发布失败时直接报错。
```

验证命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File D:\AI\IOT\tools\simulate-mqtt-report.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File D:\AI\IOT\tools\simulate-mqtt-report.ps1 -Abnormal
```

验证结果：

```text
正常 MQTT 上报已写入 device_reports。
异常 MQTT 上报已写入 device_reports。
异常 MQTT 上报自动生成 logs 记录，source=DEVICE。
设备详情页已展示 2026-07-08T12:48:54 的最新 MQTT 上报数据。
```

## 17. 2026-07-08 MQTT 正式化整理

本次目标：

```text
把 MQTT 从“脚本验证能跑通”整理为可查看状态、可说明真实设备接入方式、可排查问题的正式功能。
```

新增后端接口：

```text
GET /api/mqtt/status
```

返回内容包括：

```text
是否启用、Broker 地址、clientId、订阅 topic、QoS、连接状态、最近连接时间、最近断开时间、最近消息时间、最近消息 topic、收到数量、成功处理数量、失败数量、最近错误。
```

新增后端文件：

```text
backend/src/main/java/com/aiot/log/controller/MqttController.java
backend/src/main/java/com/aiot/log/vo/MqttStatusVO.java
```

修改后端文件：

```text
backend/src/main/java/com/aiot/log/config/MqttDeviceReportSubscriber.java
```

修改内容：

```text
记录 MQTT 连接状态和消息处理统计。
MQTT payload 解析后使用 Bean Validation 校验 DeviceReportCreateRequest，保证 MQTT 和 HTTP 上报入口使用一致的字段校验规则。
```

新增前端页面：

```text
frontend/src/views/MqttStatusView.vue
frontend/src/api/mqtt.ts
frontend/src/types/mqtt.ts
```

前端入口：

```text
/mqtt
```

页面展示：

```text
启用状态、连接状态、收到消息数、处理成功数、处理失败数、Broker、Client ID、订阅 topic、QoS、最近消息和最近错误。
```

新增文档：

```text
docs/mqtt-reporting-guide.md
```

文档说明：

```text
真实设备不运行 PowerShell 脚本，而是作为 MQTT Client 连接 Broker，然后向 aiot/device/{deviceCode}/report 发布 JSON。
如果设备不在本机，需要 Mosquitto 监听局域网地址并放行 Windows 防火墙 1883 端口。
```

验证结果：

```text
后端 mvn compile：BUILD SUCCESS
前端 npm run build：BUILD SUCCESS
```

## 13. 2026-07-08 第二阶段设备上报趋势图

本次目标：

```text
在设备详情页展示最近上报数据的趋势变化，覆盖温度、湿度、电压和信号强度。
```

新增前端文件：

```text
frontend/src/components/ReportTrendPanel.vue
```

已修改前端能力：

```text
设备详情页调用 GET /api/device-reports?page=1&pageSize=20&deviceId={id}。
设备详情页新增“上报趋势”区域。
趋势图展示温度、湿度、电压、信号强度最近 20 条数据变化。
```

验证结果：

```text
前端 npm run build：BUILD SUCCESS
```

## 14. 2026-07-08 第二阶段告警规则配置

本次目标：

```text
把设备上报异常阈值从固定代码扩展为可配置规则，并提供前端管理页面。
```

新增数据库表：

```text
alert_rules
```

新增后端接口：

```text
GET    /api/alert-rules
POST   /api/alert-rules
PUT    /api/alert-rules/{id}
DELETE /api/alert-rules/{id}
```

新增后端文件：

```text
entity/AlertRule.java
dto/AlertRuleRequest.java
vo/AlertRuleVO.java
mapper/AlertRuleMapper.java
service/AlertRuleService.java
service/impl/AlertRuleServiceImpl.java
controller/AlertRuleController.java
```

已修改后端能力：

```text
GET /api/enums 新增 alertMetric 和 alertOperator。
设备上报时优先按启用的告警规则判断异常。
没有配置任何启用规则时，保留原默认阈值逻辑。
```

新增前端文件：

```text
frontend/src/types/alertRule.ts
frontend/src/api/alertRules.ts
frontend/src/views/AlertRuleListView.vue
```

已修改前端能力：

```text
左侧导航新增“告警规则”。
告警规则页支持查询、新增、编辑、删除。
规则支持全局适用或绑定单个设备。
```

验证结果：

```text
后端 mvn compile：BUILD SUCCESS
前端 npm run build：BUILD SUCCESS
```
